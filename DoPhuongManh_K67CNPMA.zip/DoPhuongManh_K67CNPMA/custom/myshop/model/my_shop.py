# -*- coding: utf-8 -*-
from odoo import api, fields, models, tools, _
from odoo.exceptions import UserError, ValidationError

class MyShop(models.Model):
    _name = "my.shop"
    _description = "My shop model"

    name = fields.Char('Shop Name', required=True)
    nickname = fields.Char('Name')
    description = fields.Text('Shop Description')
    gender = fields.Selection([
        ('male', 'Male'),
        ('female', 'Female')
    ], string='Gender', default='male')

