# -*- coding: utf-8 -*-
{
    'name': "My shop - shopABC.info",
    'summary': """My shop model""",
    'description': """Managing shop information""",
    'author': "shopABC.info",
    'website': "https://shopABC.info",
    'category': 'Uncategorized',
    'version': '0.1',
    'depends': [
        'base',
    ],
    'data': ['view/shop_view.xml',],
    'demo': [],

    'installable': True,
    'application': True,
}
