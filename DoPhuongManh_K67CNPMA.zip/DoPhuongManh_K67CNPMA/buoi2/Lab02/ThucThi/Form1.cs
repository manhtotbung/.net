﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ThucThi
{
    public partial class Form1 : Form
    {
        string strcon = @"Data Source=M07;Initial Catalog=QLSV;Integrated Security=True";
        SqlConnection sqlCon= null;

        public Form1()
        {
            InitializeComponent();
        }
        private void MoKetNoi()
        {
            if (sqlCon == null) sqlCon = new SqlConnection(strcon);
            if(sqlCon.State ==ConnectionState.Closed) sqlCon.Open();

        }

        private void DongKetNoi()
        {
            if(sqlCon != null && sqlCon.State !=ConnectionState.Closed)
            {
                sqlCon.Close();
            }
        }
        private void btnTinhSL_Click(object sender, EventArgs e)
        {
            MoKetNoi();

            //doi tuong truy van
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType= CommandType.Text;
            sqlCmd.CommandText = "select count(*) from SinhVien";

            //gan vao ket noi
            sqlCmd.Connection = sqlCon;

            //thuc thi truy van
            int kq =(int)sqlCmd.ExecuteScalar();

            //hien thi
            MessageBox.Show("So luong sinh vien la: " + kq);
        }
    }
}
