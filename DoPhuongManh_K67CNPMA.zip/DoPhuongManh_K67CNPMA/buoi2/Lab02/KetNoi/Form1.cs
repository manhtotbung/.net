﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KetNoi
{
    public partial class Form1 : Form
    {
        string strcon = @"Data Source=M07;Initial Catalog=QLSV;Integrated Security=True";

        //doi tuong ket noi
        SqlConnection sqlcon = null;

        public Form1()
        {
            InitializeComponent();
        }

        //ham mo ket noi
        private void MoKetNoi()
        {
            if(sqlcon==null) sqlcon= new SqlConnection(strcon);
            if(sqlcon.State==ConnectionState.Closed) sqlcon.Open();
            MessageBox.Show("ket noi thanh cong");
        }

        private void DongKetNoi()
        {
            if(sqlcon!=null && sqlcon.State==ConnectionState.Open)
            {
                sqlcon.Close();
            }
        }
        private void btnKetNoi_Click(object sender, EventArgs e)
        {
            MoKetNoi()
        }
    }
}
