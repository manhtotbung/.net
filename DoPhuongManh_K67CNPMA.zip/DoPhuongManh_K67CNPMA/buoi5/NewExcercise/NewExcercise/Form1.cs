﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace NewExcercise
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            HienThiDS();
            gbTT_ChiTiet.Enabled= false; 
            btnSua.Enabled= false;
            btnXoa.Enabled= false;  
        }

        //bien local
        string strcon = @"Data Source=M07;Initial Catalog=QLSV;Integrated Security=True";
        SqlConnection sqlcon = null;    

        DataSet ds = null;
        SqlDataAdapter adapter= null;

        //mo ket noi
        private void MoKetNoi()
        {
            if (sqlcon == null) sqlcon = new SqlConnection(strcon);
            if (sqlcon.State == ConnectionState.Closed) sqlcon.Open();
        }
        //hien thi ds
        private void HienThiDS()
        {
            MoKetNoi();

            //lenh truy van
            string sql = "select * from tbl_SinhVien";
            adapter = new SqlDataAdapter(sql, sqlcon);
            SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
            ds = new DataSet();
            adapter.Fill(ds, "tblSinhVien");
            dgvDanhSach.DataSource = ds.Tables["tblSinhVien"];
        }

        //ham tim kiem

        private void TimKiemTheoMa(string maSV)
        {
            MoKetNoi();
            //lenh truy van
            string sql = "select * from tbl_SinhVien where maSV = '" + maSV + "'";
            adapter = new SqlDataAdapter(sql, sqlcon);

            ds = new DataSet();
            adapter.Fill(ds, "tblTKMa");
            dgvDanhSach.DataSource = ds.Tables["tblTKMa"];

        }
        //ham xoa dl
        private void XoaDL()
        {
            txtMaLop.Clear();
            txtTenSV.Clear();
            txtQueQuan.Clear();
            txtMaSV.Clear();
     
        }

        //them sua xoa SV
        private void ThemSV()
        {
            MoKetNoi();
            DataRow row = ds.Tables["tblSinhVien"].NewRow();
            row["maSV"] = txtMaSV.Text.Trim();
            row["tenSV"] = txtTenSV.Text.Trim();
            if(rdoNam.Checked == true)
            {
                row["gioiTinh"] = "Nam";
            }
            else if(rdoNu.Checked == true) 
            {
                row["gioiTinh"] = "Nu";   
            }
            row["ngaySinh"] = dtpNgaySinh.Value.Month + "/" + dtpNgaySinh.Value.Day + "/" + dtpNgaySinh.Value.Year;
            row["queQuan"] = txtQueQuan.Text.Trim();
            row["maLop"] = txtMaLop.Text.Trim();
            ds.Tables["tblSinhVien"].Rows.Add(row);
            int kq = adapter.Update(ds.Tables["tblSinhVien"]);
            if(kq > 0) 
            {
                HienThiDS();
                MessageBox.Show("them sv thanh cong");
           
                gbTT_ChiTiet.Enabled= false;
            }
            else
            {
                MessageBox.Show("them sv khong thanh cong");
                XoaDL();
                gbTT_ChiTiet.Enabled = false;
            }

        }

        private void SuaSV()
        {

        }
        private void TimKiemTheoTen(String tenSV)
        {
            MoKetNoi();
            //lenh truy van
            string sql = "select * from tbl_SinhVien where tenSV like N'%" + tenSV + "%'";
            adapter = new SqlDataAdapter(sql, sqlcon);

            ds = new DataSet();
            adapter.Fill(ds, "tblTKTen");
            dgvDanhSach.DataSource = ds.Tables["tblTKTen"];
        }
        private void Form1_Load(object sender, EventArgs e)
        {
         
        }
        private void btnThoat_Click(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show("Bạn có thực sự muốn thoát?", "Hộp thoại", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes) { Close(); }
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            string maSV = txtTimMaSV.Text;
            string tenSV = txtTimTenSV.Text;
            if (maSV == "" && tenSV != "")
            {
                TimKiemTheoTen(tenSV);
            }
            else if (maSV != "" && tenSV == "")
            {
                TimKiemTheoMa(maSV);
            }
            else if (maSV != "" && tenSV != "")
            {
                TimKiemTheoMa(maSV);
            }
            else
               MessageBox.Show("bạn chưa nhập tt!");
               txtMaSV.Focus();

        }

        int chucNang = 0;
        private void btnThem_Click(object sender, EventArgs e)
        {
            gbTT_ChiTiet.Enabled= true;
            chucNang = 1;

        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            gbTT_ChiTiet.Enabled = true;
            chucNang = 2;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if(chucNang == 1)
            {
                ThemSV();
            }
            else if(chucNang == 2)
            {
                SuaSV();
            }
        }
        int vt = -1;

        private void dgvDanhSach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            vt = e.RowIndex;

        }
    }
}
