﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string pass;
        private void Form1_Load(object sender, EventArgs e)
        {
            pass = "";
        }

        private void btn01_Click(object sender, EventArgs e)
        {
            pass += "1";
            txtPass.Text = pass;

        }

        private void btn02_Click(object sender, EventArgs e)
        {
            pass += "2";
            txtPass.Text = pass;
        }

        private void btn03_Click(object sender, EventArgs e)
        {
            pass += "3";
            txtPass.Text = pass;
        }

        private void btn04_Click(object sender, EventArgs e)
        {
            pass += "4";
            txtPass.Text = pass;
        }

        private void btn05_Click(object sender, EventArgs e)
        {
            pass += "5";
            txtPass.Text = pass;
        }

        private void btn06_Click(object sender, EventArgs e)
        {
            pass += "6";
            txtPass.Text = pass;
        }

        private void btn07_Click(object sender, EventArgs e)
        {
            pass += "7";
            txtPass.Text = pass;
        }

        private void btn08_Click(object sender, EventArgs e)
        {
            pass += "8";
            txtPass.Text = pass;
        }

        private void btn09_Click(object sender, EventArgs e)
        {
            pass += "9";
            txtPass.Text = pass;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            txtPass.Clear();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (pass == "1469" || pass == "2673")
            {
                ListViewItem lvi = new ListViewItem(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                lvi.SubItems.Add("Phát triển công nghệ");
                lvi.SubItems.Add("Chấp nhận");

                //them dong moi vao list view
                lsvKetQua.Items.Add(lvi);
            }
        }
    }
}
