﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            txtNhapA.Clear();
            txtNhapB.Clear();
            txtKetQua.Clear();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("hỏi thoát", "ban co muon thoat khong?", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnTru_Click(object sender, EventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(txtNhapA.Text);
                int b = Convert.ToInt32(txtNhapB.Text);

                int tong = a - b;
                txtKetQua.Text = tong.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(" không phải là số" + ex);
                throw;
            }

        }


        private void btnCong_Click(object sender, EventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(txtNhapA.Text);
                int b = Convert.ToInt32(txtNhapB.Text);

                int tong = a + b;
                txtKetQua.Text = tong.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(" không phải là số" + ex);
                throw;
            }

        }

    

    private void btnNhan_Click(object sender, EventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(txtNhapA.Text);
                int b = Convert.ToInt32(txtNhapB.Text);

                int tong = a * b;
                txtKetQua.Text = tong.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"lỗi bạn nhập không phải là số", MessageBoxButtons.OKCancel);
                throw;
            }
          
        }

        private void btnChia_Click(object sender, EventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(txtNhapA.Text);
                int b = Convert.ToInt32(txtNhapB.Text);
                if (b == 0)
                {
                    MessageBox.Show("Mẫu số không được bằng 0, try again!");
                    txtNhapB.Clear();

                }
                float tong = (float)a / b;
                txtKetQua.Text = tong.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show(" không phải là số" + ex.ToString());
               
            }
        }
    }
}
