﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace lab05
{
    
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        //chuoi ket noi
        string strcon = @"Data Source=M07;Initial Catalog=QLSV;Integrated Security=True";
        //doi tuong ket noi
        SqlConnection sqlcon = null;

        //ham mo ket noi
        private void MoKetNoi()
        {
            if (sqlcon==null) { sqlcon = new SqlConnection(strcon); }
            if(sqlcon.State== ConnectionState.Closed) { sqlcon.Open(); }
        }

        //hien thi danh sach sinh vien (listview)
        private void HienThiDS_SinhVien() 
        {
            MoKetNoi();

            //doi tuong truy van
            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.CommandType = CommandType.Text;
            sqlcmd.CommandText = "select * from tbl_sinhvien";

            //gan vao ket noi
            sqlcmd.Connection = sqlcon;

            //thuc thi truy van 
            SqlDataReader reader = sqlcmd.ExecuteReader();
            lsvDanhSach.Items.Clear();
            while(reader.Read())
            {
                //doc dl tu csdl
                string MaSV = reader.GetString(0).Trim();
                string TenSV = reader.GetString(1).Trim();
                string GioiTinh = reader.GetString(2).Trim();
                string NgaySinh = reader.GetDateTime(3).ToString("MM/dd/yyyy");
                string QueQuan = reader.GetString(4).Trim();
                string MaLop = reader.GetString(5).Trim();

                //tao 1 dong moi
                ListViewItem lvi = new ListViewItem(MaSV);
                lvi.SubItems.Add(TenSV);
                lvi.SubItems.Add(GioiTinh);
                lvi.SubItems.Add(NgaySinh);
                lvi.SubItems.Add(QueQuan);
                lvi.SubItems.Add(MaLop);

                //gan dong moi vao list view
                lsvDanhSach.Items.Add(lvi);
            }
            reader.Close();
        }

        //ham tim kiem theo ma
        private void TimKiemTheoMa(string MaSV)
        {
            MoKetNoi();

            //doi tuong truy van
            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.CommandType = CommandType.Text;
            sqlcmd.CommandText = "select * from tbl_sinhvien where MaSV = '"+MaSV+"'";

            //gan vao ket noi
            sqlcmd.Connection = sqlcon;

            //thuc thi truy van 
            SqlDataReader reader = sqlcmd.ExecuteReader();
            lsvDanhSach.Items.Clear();
            while (reader.Read())
            {
                //doc dl tu csdl
                string _MaSV = reader.GetString(0).Trim();
                string TenSV = reader.GetString(1).Trim();
                string GioiTinh = reader.GetString(2).Trim();
                string NgaySinh = reader.GetDateTime(3).ToString("mm/dd.yyyy");
                string QueQuan = reader.GetString(4).Trim();
                string MaLop = reader.GetString(5).Trim();

                //tao 1 dong moi
                ListViewItem lvi = new ListViewItem(MaSV);
                lvi.SubItems.Add(TenSV);
                lvi.SubItems.Add(GioiTinh);
                lvi.SubItems.Add(NgaySinh);
                lvi.SubItems.Add(QueQuan);
                lvi.SubItems.Add(MaLop);

                //gan dong moi vao list view
                lsvDanhSach.Items.Add(lvi);
            }
            reader.Close();
        }

        private void TimKiemTheoTen(string TenSV)
        {
            MoKetNoi();

            //doi tuong truy van
            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.CommandType = CommandType.Text;
            sqlcmd.CommandText = "select * from tbl_sinhvien where TenSV like '%"+TenSV+"%'";

            //gan vao ket noi
            sqlcmd.Connection = sqlcon;

            //thuc thi truy van 
            SqlDataReader reader = sqlcmd.ExecuteReader();
            lsvDanhSach.Items.Clear();
            while (reader.Read())
            {
                //doc dl tu csdl
                string MaSV = reader.GetString(0).Trim();
                string _TenSV = reader.GetString(1).Trim();
                string GioiTinh = reader.GetString(2).Trim();
                string NgaySinh = reader.GetDateTime(3).ToString("MM/dd.yyyy");
                string QueQuan = reader.GetString(4).Trim();
                string MaLop = reader.GetString(5).Trim();

                //tao 1 dong moi
                ListViewItem lvi = new ListViewItem(MaSV);
                lvi.SubItems.Add(_TenSV);
                lvi.SubItems.Add(GioiTinh);
                lvi.SubItems.Add(NgaySinh);
                lvi.SubItems.Add(QueQuan);
                lvi.SubItems.Add(MaLop);

                //gan dong moi vao list view
                lsvDanhSach.Items.Add(lvi);
            }
            reader.Close();
        }
        //xoa du lieu tren form
        private void xoaDuLieuForm() 
        {
            txtMaSV.Clear();
            txtTenSV.Clear();
            txtQueQuan.Clear();
            txtMaLop.Clear();
            
        }
        //ham them sua xoa sinh vien
        private void themSinhVien()
        {
            try
            {
                //lay dl tren form
                string maSV = txtMaSV.Text.Trim();
                string tenSV = txtTenSV.Text.Trim();
                string gioiTinh = "";
                if(cbGioiTinh.SelectedIndex== 0)
                {
                    gioiTinh = "Nam";
                }  
                else if(cbGioiTinh.SelectedIndex==1)
                {
                    gioiTinh = "Nữ";
                }

                string ngaySinh = dtpNgaySinh.Value.Year + "-" + dtpNgaySinh.Value.Month + "-" + dtpNgaySinh.Value.Day;
                string queQuan = txtQueQuan.Text.Trim();
                string maLop = txtMaLop.Text.Trim();

                //mo ket noi
                MoKetNoi();

                //doi tuong truy van 
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandType = CommandType.Text;
                sqlcmd.CommandText = "insert into tbl_sinhvien values('"+maSV+"',N'"+tenSV+"',N'"+gioiTinh+"',CONVERT(datetime,'"+ngaySinh+"'),N'"+queQuan+"','"+maLop+"')";

                //gan vao ket noi
                sqlcmd.Connection = sqlcon;
                //thuc thi
                int kq = sqlcmd.ExecuteNonQuery();
                if(kq > 0 )
                {
                    MessageBox.Show("them sv thanh cong");
                    HienThiDS_SinhVien();
                    xoaDuLieuForm();
                    groupBox2.Enabled= false;
                }
                else
                {
                    MessageBox.Show("thêm sv ko thành công");
                } 
                    


            }
            catch (Exception ex)
            {
                MessageBox.Show("loi khong nhap dung dinh dang" + ex.Message);
            }

        }
        
        private void suaTTSinhVien()
        {
            try
            {
                //lay dl tren form
                string maSV = txtMaSV.Text.Trim();
                string tenSV = txtTenSV.Text.Trim();
                string gioiTinh = "";
                if (cbGioiTinh.SelectedIndex == 0)
                {
                    gioiTinh = "Nam";
                }
                else if (cbGioiTinh.SelectedIndex == 1)
                {
                    gioiTinh = "Nữ";
                }

                string ngaySinh = dtpNgaySinh.Value.Year + "-" + dtpNgaySinh.Value.Month + "-" + dtpNgaySinh.Value.Day;
                string queQuan = txtQueQuan.Text.Trim();
                string maLop = txtMaLop.Text.Trim();

                //mo ket noi
                MoKetNoi();

                //doi tuong truy van 
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandType = CommandType.Text;
                sqlcmd.CommandText = "update tbl_sinhvien set maSV='"+maSV+"', tenSV = N'"+tenSV+"', gioiTinh = N'"+gioiTinh+"', ngaySinh = CONVERT(datetime, '"+ngaySinh+"'), queQuan = N'"+queQuan+"', maLop = N'"+maLop+"' where maSV = '"+maSV+"'";

                //gan vao ket noi
                sqlcmd.Connection = sqlcon;
                //thuc thi
                int kq = sqlcmd.ExecuteNonQuery();
                if (kq > 0)
                {
                    MessageBox.Show("sua tt sv thanh cong");
                    HienThiDS_SinhVien();
                    xoaDuLieuForm();
                    groupBox2.Enabled = false;
                }
                else
                {
                    MessageBox.Show("sua tt sv ko thành công");
                }



            }
            catch (Exception ex)
            {
                MessageBox.Show("loi khong nhap dung dinh dang" + ex.Message);
            }
            btnSua.Enabled= false;
            btnXoa.Enabled= false;
        }
        string maSV_xoa = "";
        private void xoaSinhVien()
        {
            
            //mo ket noi
            MoKetNoi();


            //doi tuong truy van 
            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.CommandType = CommandType.Text;
            sqlcmd.CommandText = " delete from tbl_sinhvien where maSV = '"+maSV_xoa+"' ";

            //gan vao ket noi
            sqlcmd.Connection = sqlcon;
            //thuc thi
            int kq = sqlcmd.ExecuteNonQuery();
            if (kq > 0)
            {
                MessageBox.Show("sua tt sv thanh cong");
                HienThiDS_SinhVien();
                xoaDuLieuForm();
                groupBox2.Enabled = false;
            }
            else
            {
                MessageBox.Show("sua tt sv ko thành công");
            }


            btnSua.Enabled= false;
            btnXoa.Enabled= false;
        }


        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có thực sự muốn thoát không?", "Hộp thoại", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes) { Close(); }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            HienThiDS_SinhVien();
            btnSua.Enabled= false;
            btnXoa.Enabled= false;
            groupBox4.Enabled= false;

            cbGioiTinh.Items.Add("Nam");
            cbGioiTinh.Items.Add("Nữ");
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            //lay du lieu tu form
            string MaSV = txtTKMaSV.Text.Trim();
            string TenSV = txtTKTenSV.Text.Trim();

            //phan chia truong hop
            if (MaSV != "" && TenSV == "")
                TimKiemTheoMa(MaSV);
            else if (MaSV == "" && TenSV != "")
                TimKiemTheoTen(TenSV);
            else if (MaSV != "" && TenSV != "")
                TimKiemTheoMa(MaSV);
            else
            {
                MessageBox.Show("you haven't type what you need yet!");
                txtMaSV.Focus();
            }    
                
        }

        //phan loai chuc nang
        int chucNang = 0;

        private void btnThem_Click(object sender, EventArgs e)
        {
            chucNang = 1; //
            groupBox4.Enabled = true;

        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            chucNang = 2;
            groupBox4.Enabled = true;

        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if(chucNang == 1)
            {
                themSinhVien();
            }    
            else if(chucNang == 2)
            {
                suaTTSinhVien();
            }    
        }

        private void lsvDanhSach_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnSua.Enabled= true;
            btnXoa.Enabled= true;   

            //xac dinh dong dl dươc chon
            if (lsvDanhSach.SelectedItems.Count == 0) return;
            ListViewItem lvi = lsvDanhSach.SelectedItems[0];

            //fill du lieu sang truong tt chi tiet
            txtMaSV.Text = lvi.SubItems[0].Text;
            txtTenSV.Text= lvi.SubItems[1].Text;
            if (lvi.SubItems[2].Text.Trim() == "Nam")
                 cbGioiTinh.SelectedIndex= 0;
              
            else cbGioiTinh.SelectedIndex= 1;

            string[] ns = lvi.SubItems[3].Text.Trim().Split('/');//la / vi subitem hien thi theo kieu /(using message box to check it's values)
            dtpNgaySinh.Value = new DateTime(int.Parse(ns[2]), int.Parse(ns[0]), int.Parse(ns[1]));

            txtQueQuan.Text = lvi.SubItems[4].Text;
            txtMaLop.Text = lvi.SubItems[5].Text;
            maSV_xoa = lvi.SubItems[0].Text.Trim();



        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "bạn có thực sự muốn xóa?",
                "Hộp thoại",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
                );

            if(result == DialogResult.Yes)
            {
                xoaSinhVien();
            }    
        }
    }

}
